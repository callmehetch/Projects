<?php



$mailhost = 'smtp.gmail.com';
$mailusername = 'warden_boys@iiitdm.ac.in';
$mailpass = 'jagadeesh2018$';
$mailsmtp = 'tls';
$mailport = '587';



?>
