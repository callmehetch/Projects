<?php

/* Google App Client Id */
define('CLIENT_ID', '811095232910-himuoec84blql8col3b7mm14ehklgkbi.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'UoH8YTax2DQnd8_IzDL-cgxs');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/loggedin.php');

?>
